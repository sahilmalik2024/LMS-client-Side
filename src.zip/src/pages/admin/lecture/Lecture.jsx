import { Edit } from "lucide-react";
import React from "react";
import { useNavigate } from "react-router-dom";
import PropTypes from "prop-types";

const Lecture = ({ lecture, courseId, index }) => {
    const navigate = useNavigate();
    const goToUpdateLecture = () => {
        navigate(`${lecture._id}`);
    };
    return (
        <div className="flex items-center justify-between bg-[#F7F9FA] dark:bg-[#1F1F1F] px-4 py-2 rounded-md my-2">
            <h1 className="font-bold text-gray-800 dark:text-gray-100">
                Lecture - {index + 1}: {lecture.lectureTitle}
            </h1>
            <Edit
                onClick={goToUpdateLecture}
                size={20}
                className=" cursor-pointer text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400"
            />
        </div>
    );
};

Lecture.propTypes = {
    lecture: PropTypes.shape({
      _id: PropTypes.string.isRequired, // Ensure lecture has a required `_id` of type string
      lectureTitle: PropTypes.string.isRequired, // Ensure `lectureTitle` is a required string
    }).isRequired, // The `lecture` prop is required
    courseId: PropTypes.string, // `courseId` is optional but should be a string if provided
    index: PropTypes.number.isRequired, // Ensure `index` is a required number
  };

export default Lecture;
